-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Jeu 07 Août 2014 à 11:13
-- Version du serveur: 5.5.38-0ubuntu0.14.04.1
-- Version de PHP: 5.5.9-1ubuntu4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `my_meetic`
--

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `messages_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `body` varchar(255) CHARACTER SET utf8 NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int(11) NOT NULL DEFAULT '0',
  `trash` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`messages_id`),
  KEY `from_user_id` (`from_user_id`),
  KEY `to_user_id` (`to_user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `messages`
--

INSERT INTO `messages` (`messages_id`, `from_user_id`, `to_user_id`, `body`, `created`, `state`, `trash`) VALUES
(1, 2, 1, 'salut salut ! tu baise? ', '2014-08-01 09:59:43', 1, 0),
(2, 1, 2, 'Ouai mais je suis tr&egrave;s cher !', '2014-08-01 10:01:46', 1, 0),
(3, 3, 3, 'dqD', '2014-08-01 10:19:05', 1, 2),
(4, 3, 1, 'DSQFZQFSDQFSQ', '2014-08-01 10:19:21', 1, 0),
(5, 4, 4, 'Salut toi !', '2014-08-01 10:31:35', 1, 0),
(6, 4, 4, 'Bonjour', '2014-08-01 10:31:55', 1, 0),
(7, 4, 3, 'Salut bo goss, ta fait de la muscu a ce que je vois ;) T''es c&eacute;lib ?', '2014-08-01 10:32:52', 1, 0),
(8, 5, 3, 'Veux tu devenir mon prince charmant ?', '2014-08-01 10:48:28', 1, 0),
(9, 6, 4, 'Je suis ', '2014-08-06 08:47:51', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sexe` varchar(1) NOT NULL,
  `anniversaire` date NOT NULL,
  `ville` varchar(255) NOT NULL,
  `departement` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `pays` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text NOT NULL,
  `token` varchar(255) NOT NULL,
  `validation` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`user_id`, `pseudo`, `password`, `nom`, `prenom`, `email`, `sexe`, `anniversaire`, `ville`, `departement`, `region`, `pays`, `created`, `description`, `token`, `validation`, `state`) VALUES
(1, 'villers', 'fc588b4d172bab7abe83c7c8baaed139', 'villers', 'mickael', 'villersm@hotmail.com', 'M', '1990-12-30', 'Saint-Louis', 'Haut-Rhin', 'Alsace', 'France', '2014-08-01 09:53:23', 'Je recherche un Pangolin Sexy', '', 1, 0),
(2, 'Hectelyon', '1c9977ff8e9e603263b25b61c1d6da8c', 'gonçal', 'guillaume', 'goncalvesguillaume23@gmail.com', 'M', '1990-11-23', 'Saint-etienne', 'Rhône', 'Rhône-Alpes', 'France', '2014-08-01 09:57:15', 'My meetic sa me gave !', '', 1, 0),
(3, 'Nany', '50d1b2a10fc5924dc844312868428942', 'issop', 'tidjani', 't.issop69@gmail.com', 'M', '1991-01-03', 'Pierre-Bénite', 'Rhône', 'Rhône-alpes', 'France', '2014-08-01 10:16:20', 'dqsdsq', '', 1, 0),
(4, 'py1903', '5e05d9a27e448a75a3ce1c91d47ed79d', 'Clerc', 'Pierre-Yves', 'py1903@hotmail.com', 'M', '1992-03-19', 'Lyon', 'Rhône', 'Rhône-Alpes', 'France', '2014-08-01 10:29:02', 'Chloé tu es vraiment mignonne, tu est libre ce soir', '', 1, 0),
(5, 'Julie', '73f0e6aa971d34e92ebc53fcbe4d1ca0', 'Bridge', 'Julie', 'julie.bourguignon@epitech.eu', 'F', '1993-02-04', 'Heyrieux', 'Isère', 'Rhône-Alpes', 'France', '2014-08-01 10:46:05', 'Je cherche mon prince charmant !', '', 1, 0),
(6, 'Georges', 'ab4f63f9ac65152575886860dde480a1', 'Georges', 'Georges', 'jonas.duhamel@epitech.eu', 'M', '1989-02-24', 'Lyon', 'Rhône', 'Rhône-Alpes', 'Fraour', '2014-08-06 08:45:03', 'Recherche Milf', '', 1, 0),
(7, '3nzo', 'ab4f63f9ac65152575886860dde480a1', 'Mariet', 'Enzo', 'mariet_e@epitech.eu', 'A', '1992-03-03', 'Lyon', 'Rhône', 'Rhône-Alples', 'France', '2014-08-07 08:59:14', '', '', 1, 0);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
